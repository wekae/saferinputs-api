<?php


namespace App\Repositories;


use App\Facades\UtilsFacade;
use App\Models\ActiveIngredients;
use App\Models\Agrochem;

class ActiveIngredientsRepositoryMySqlImpl implements ActiveIngredientsRepository
{

    protected  $activeIngredients;
    public function __construct(ActiveIngredients $activeIngredients)
    {
        $this->activeIngredients = $activeIngredients;
    }

    public function create($attributes)
    {
        $request = $attributes['request'];
        $saved_item = $this->activeIngredients->create($request->only(
            [
                'name',
                'potential_harm',
                'aquatic',
                'aquatic_desc',
                'bees',
                'bees_desc',
                'earthworm',
                'earthworm_desc',
                'birds',
                'birds_desc',
                'leachability',
                'leachability_desc',
                'carcinogenicity',
                'mutagenicity',
                'edc',
                'reproduction',
                'ache',
                'neurotoxicant',
                'who_classification',
                'eu_approved',
            ]
        ))->refresh();

        $saved_item->agrochem()->saveMany(Agrochem::findMany($request->agrochems));

        //Save image
        $image = $request->image;
        if($image!=null) {
            $saved_item = UtilsFacade::uploadImage($image, $saved_item);
        }

        return $saved_item->refresh();
    }

    public function all($attributes){
        $request = $attributes["request"];
        $order_column = $request->order_column;
        $order_direction = $request->order_direction;
        $per_page = $request->per_page;
        if($order_column==null){
            $order_column="id";
        }
        if($order_direction==null){
            $order_direction="asc";
        }
        if($per_page==null){
            $per_page=config('app.items_per_page');
        }
        return $this->activeIngredients
            ->orderBy($order_column, $order_direction)
            ->paginate($per_page);
    }

    public function find($id){
        return $this->activeIngredients->find($id);
    }

    public function findAgrochems($attributes){
        $request = $attributes['request'];
        $items = ActiveIngredients::with(['agrochem' => function($query) use($request){
            $product_name = $request->product_name;
            if($product_name){
                $query->where('product_name','like','%'.$product_name.'%');
            }
            $pcpb_number = $request->pcpb_number;
            if($pcpb_number){
                $query->where('pcpb_number','like','%'.$pcpb_number.'%');
            }
            $distributing_company = $request->distributing_company;
            if($distributing_company){
                $query->where('distributing_company','like','%'.$distributing_company.'%');
            }
            $toxic = $request->toxic;
            if($toxic){
                $query->where('toxic',UtilsFacade::formatToBinary($toxic));
            }
            $who_class = $request->who_class;
            if($who_class){
                $query->where('who_class','like','%'.$who_class.'%');
            }
            $composition = $request->composition;
            if($composition){
                $query->where('composition','like','%'.$composition.'%');
            }
            $registrant = $request->registrant;
            if($registrant){
                $query->where('registrant','like','%'.$registrant.'%');
            }
            $type = $request->type;
            if($type){
                $query->where('type','like','%'.$type.'%');
            }
            $phi_days = $request->phi_days;
            if($phi_days){
                $query->where('phi_days',$phi_days);
            }
        }])->where('id',$request->id)->first();
        return $items;
    }

    public function getActiveIngredientNames(){
        return $this->activeIngredients->select('id','name')->orderBy('name', 'asc')->get();
    }

    public function update($id, array $attributes)
    {
        $request = $attributes['request'];

        $item = $this->activeIngredients->find($id);
        if($item){
            $this->activeIngredients->find($id)->update($request->only(
                [
                    'name',
                    'potential_harm',
                    'aquatic',
                    'aquatic_desc',
                    'bees',
                    'bees_desc',
                    'earthworm',
                    'earthworm_desc',
                    'birds',
                    'birds_desc',
                    'leachability',
                    'leachability_desc',
                    'carcinogenicity',
                    'mutagenicity',
                    'edc',
                    'reproduction',
                    'ache',
                    'neurotoxicant',
                    'who_classification',
                    'eu_approved',
                ]
            ));


            $item->agrochem()->sync(Agrochem::findMany($request->agrochems));

            return $item->refresh();
        }else{
            return false;
        }
    }

    public function delete($id)
    {
        $item = $this->activeIngredients->find($id);
        if($item){
            $item->delete();
            return true;
        }else{
            return false;
        }
    }

    public function filter(array $attributes){
        $request = $attributes["request"];
        $search_value = $request->search_value;
        $order_column = $request->order_column;
        $order_direction = $request->order_direction;
        $per_page = $request->per_page;

        if($order_column==null){
            $order_column="id";
        }
        if($order_direction==null){
            $order_direction="desc";
        }
        if($per_page==null){
            $per_page=config('app.items_per_page');;
        }

        $columns_array = array (
            'name',
            'potential_harm',
            'aquatic',
            'aquatic_desc',
            'bees',
            'bees_desc',
            'earthworm',
            'earthworm_desc',
            'birds',
            'birds_desc',
            'leachability',
            'leachability_desc',
            'carcinogenicity',
            'mutagenicity',
            'edc',
            'reproduction',
            'ache',
            'neurotoxicant',
            'who_classification',
            'eu_approved',
        );

        $data = ActiveIngredients::select();



        /**
         * Filter data based on the search query
         */
        if($search_value){
            /**
             * create a nested OR clause to search by specific column
             */
            $data = $data->where(function($query) use($columns_array, $search_value, $request){
                /**
                 * append each table column to the query
                 */
                foreach ($columns_array as $column){
                    $query->orWhere($column,'like','%'.$search_value.'%');
                }
            });
        }else{
            /*
             * Search spefific columns
             */
            $name = $request->name;
            if($name){
                $data = $data->where('name','like','%'.$name.'%');
            }
            $potential_harm = $request->potential_harm;
            if($potential_harm){
                $data = $data->where('potential_harm','like','%'.$potential_harm.'%');
            }
            $aquatic = $request->aquatic;
            if($aquatic){
                $data = $data->where('aquatic','like','%'.$aquatic.'%');
            }
            $aquatic_desc = $request->aquatic_desc;
            if($aquatic_desc){
                $data = $data->where('aquatic_desc','like','%'.$aquatic_desc.'%');
            }
            $bees = $request->bees;
            if($bees){
                $data = $data->where('bees','like','%'.$bees.'%');
            }
            $bees_desc = $request->bees_desc;
            if($bees_desc){
                $data = $data->where('bees_desc','like','%'.$bees_desc.'%');
            }
            $earthworm = $request->earthworm;
            if($earthworm){
                $data = $data->where('earthworm','like','%'.$earthworm.'%');
            }
            $earthworm_desc = $request->earthworm_desc;
            if($earthworm_desc){
                $data = $data->where('earthworm_desc','like','%'.$earthworm_desc.'%');
            }
            $birds = $request->birds;
            if($birds){
                $data = $data->where('birds','like','%'.$birds.'%');
            }
            $birds_desc = $request->birds_desc;
            if($birds_desc){
                $data = $data->where('birds_desc','like','%'.$birds_desc.'%');
            }
            $leachability = $request->leachability;
            if($leachability){
                $data = $data->where('leachability','like','%'.$leachability.'%');
            }
            $leachability_desc = $request->leachability_desc;
            if($leachability_desc){
                $data = $data->where('leachability_desc','like','%'.$leachability_desc.'%');
            }
            $carcinogenicity = $request->carcinogenicity;
            if($carcinogenicity){
                $data = $data->where('carcinogenicity','like','%'.$carcinogenicity.'%');
            }
            $mutagenicity = $request->mutagenicity;
            if($mutagenicity){
                $data = $data->where('mutagenicity','like','%'.$mutagenicity.'%');
            }
            $edc = $request->edc;
            if($edc){
                $data = $data->where('edc','like','%'.$edc.'%');
            }
            $reproduction = $request->reproduction;
            if($reproduction){
                $data = $data->where('reproduction','like','%'.$reproduction.'%');
            }
            $ache = $request->ache;
            if($ache){
                $data = $data->where('ache','like','%'.$ache.'%');
            }
            $neurotoxicant = $request->neurotoxicant;
            if($neurotoxicant){
                $data = $data->where('neurotoxicant','like','%'.$neurotoxicant.'%');
            }
            $who_classification = $request->who_classification;
            if($who_classification){
                $data = $data->where('who_classification','like','%'.$who_classification.'%');
            }
            $eu_classification = $request->eu_classification;
            if($eu_classification){
                $data = $data->where('eu_classification','like','%'.$eu_classification.'%');
            }
        }





        /**
         * Set ordering
         */
        $data = $data->orderBy($order_column, $order_direction);


        /**
         * Get the filtered records
         */
        $data = $data->paginate($per_page);
        return $data;
    }

    public function datatable(array $attributes)
    {
        $request = $attributes["request"];


        (int)$draw = $request->draw;
        $start = $request->start;
        $length = $request->length;
        $search_value = $request->search["value"];
        $order_array = $request->order;
        $columns_array = $request->columns;

//        Initial Query  with fields to be selected
        $data = ActiveIngredients::select(
            'id',
            'name',
            'potential_harm',
            'aquatic',
            'aquatic_desc',
            'bees',
            'bees_desc',
            'earthworm',
            'earthworm_desc',
            'birds',
            'birds_desc',
            'leachability',
            'leachability_desc',
            'carcinogenicity',
            'mutagenicity',
            'edc',
            'reproduction',
            'ache',
            'neurotoxicant',
            'who_classification',
            'eu_approved'
        );
        $recordsFiltered = ActiveIngredients::count();


//        Filter data based on the search query
        if($search_value){
//            create an AND with nested OR clause
            $data = $data->where(function($query) use($columns_array, $search_value){
//                append each table column to the query
                foreach ($columns_array as $column){
                    $query->orWhere($column['data'],'like','%'.$search_value.'%');
                }

            });
            $recordsFiltered = $data->count();
        }


//        Set ordering
        if($order_array){
            foreach ($order_array as $order){
                $column_index = $order['column'];

                $order_column = $columns_array[$column_index]['data'];
                $order_direction = $order["dir"];

                $data = $data->orderBy($order_column, $order_direction);
            }
        }


//        Set limit and offset for pagination
        if($start){
            $data = $data
                ->skip($start);
        }
        if($length){
            $data = $data
                ->take($length);
        }

        $data = $data->get();

        $recordsTotal = ActiveIngredients::count();



        return response()->json(['draw'=>$draw, 'recordsTotal'=>$recordsTotal, 'recordsFiltered'=>$recordsFiltered, 'data'=>$data]);


    }


}
