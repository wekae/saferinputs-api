<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class ControlMethods extends Model
{

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'control_methods';



    const CREATED_AT = 'creation_date';
    const UPDATED_AT = 'last_update';

    protected $fillable = [
        'name',
        'options',
        'category',
        'external_links',
    ];

    protected  $hidden = [
        'creation_date',
        'last_update',
        'created_at',
        'updated_at',
        'pivot',
    ];




    public function pestsDiseaseWeeds(){
        return $this->belongsToMany('App\Models\PestsDiseaseWeed', 'pests_disease_weed_control_methods', 'control_methods_id', 'pest_disease_weed_id');
    }

    public function commercialOrganic(){
        return $this->belongsToMany('App\Models\CommercialOrganic', 'control_methods_commercial_organic', 'control_methods_id', 'commercial_organic_id');
    }

}
