<?php


namespace App\Repositories;


interface CropsRepository extends CRUDRepository
{
    public function filter(array $attributes);

    public function datatable(array $attributes);

    public function findPestsDiseasesWeeds($id);

    public function findAgrochems($id);

    public function getCropNames();
}
