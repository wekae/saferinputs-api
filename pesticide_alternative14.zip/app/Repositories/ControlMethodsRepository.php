<?php


namespace App\Repositories;


interface ControlMethodsRepository extends CRUDRepository
{
    public function filter(array $attributes);

    public function datatable(array $attributes);

    public function findPestsDiseasesWeeds($id);

    public function findCommercialOrganic($id);

    public function getControlMethodNames();
}

