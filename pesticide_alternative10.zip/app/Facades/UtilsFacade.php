<?php


namespace App\Facades;


use Illuminate\Support\Facades\Facade;

/**
 * Facade to be used with Utils class in Services
 * Class UtilsFacade
 * @package App\Facades
 * @method static void  formatToBinary($value) Convert value to 0 or 1.
 */
class UtilsFacade extends Facade
{
    protected static function getFacadeAccessor(){
        return 'utils';
    }
}
