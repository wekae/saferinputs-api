<?php


namespace App\Services;


use Exception;
use Intervention\Image\Exception\NotWritableException;
use Intervention\Image\Facades\Image;

class ImageService extends FileService
{
    private $basePath = 'assets/img/';

    public function encode($image){

    }

    public function save($image, $fileName){
        $path = $this->basePath.$fileName;

        // resizing an uploaded file
            Image::make($image)->save($path);
        try{
            return array(
                'status'=>true
            );
        }catch (NotWritableException $e){
            return array(
                'status'=>false,
                'message'=>'Path does not exist'
            );
        }catch (Exception $e){
            return array(
                'status'=>false
            );
        }
    }

    public function get($filename){
        $path = $this->basePath.$filename;
        try{
            $img = Image::make($path);
            return array(
                'status'=>true,
                'image'=>$img
            );
        }catch(Exception $e){
            return array(
                'status'=>false,
                'message'=>'Image does not exist'
            );
        }
    }

    public function getResizedSquare($filename, $dim){
        $path = $this->basePath.$filename;
        try{
            $img = Image::make($path)->resize($dim, $dim);
            return array(
                'status'=>true,
                'image'=>$img
            );
        }catch(Exception $e){
            return array(
                'status'=>false,
                'message'=>'Image does not exist'
            );
        }
    }

    public function getResizedRectangle($filename, $dimX, $dimY){
        $path = $this->basePath.$filename;
        try{
            $img = Image::make($path)->resize($dimX, $dimY);
            return array(
                'status'=>true,
                'image'=>$img
            );
        }catch(Exception $e){
            return array(
                'status'=>false,
                'message'=>'Image does not exist'
            );
        }
    }

}
