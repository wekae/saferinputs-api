<?php


namespace App\Repositories;


use App\Facades\UtilsFacade;
use App\Http\Resources\CropsCollection;
use App\Http\Resources\CropsResource;
use App\Models\Agrochem;
use App\Models\Crops;
use App\Models\PestsDiseaseWeed;
use App\Services\ImageService;
use Illuminate\Database\QueryException;

class CropsRepositoryMysqlImpl implements CropsRepository
{
    protected  $crops;
    protected  $imageService;
    public function __construct(Crops $crops, ImageService $imageService)
    {
        $this->crops = $crops;
        $this->imageService = $imageService;
    }

    public function create($attributes)
    {
        try{
            $request = $attributes['request'];
            $data = $this->crops->create($request->only(
                [
                    'name',
                ]
            ))->refresh();

            $data->pestsDiseaseWeed()->saveMany(PestsDiseaseWeed::findMany($request->pests_disease_weed));
            $data->agrochem()->saveMany(Agrochem::findMany($request->agrochems));

            //Save image
            $image = $request->image;
            if($image) {
                $data = UtilsFacade::uploadImage($image, $data);
            }
            return array(
                'success'=>true,
                'item'=>$data
            );
        }catch (QueryException $e) {
            $error_code = $e->errorInfo[1];
            //Determine duplicate key using error code
            if ($error_code == 1062) {
                $return_date = array(
                    'success'=>false,
                    'duplicate'=>true);
                return $return_date;
            }
        }
//        //handle mass insert
//        return array(
//            'success'=>true,
//            'item'=>$this->crops->insertOrIgnore($attributes)
//        );
    }

    public function all($attributes){
        $request = $attributes['request'];
        $per_page = $request->per_page;
        if($per_page==null){
            $per_page=config('app.items_per_page');
        }
        return $this->crops
            ->paginate($per_page);
    }

    public function find($id){
        return $this->crops->find($id);
    }

    public function findPestsDiseasesWeeds($id){
        $items = Crops::with('pestsDiseaseWeed')->where('id',$id)->first();
        return $items;
    }

    public function findAgrochems($attributes){
        $request = $attributes['request'];

        $items = Crops::with(['agrochem' => function($query) use($request){
            $product_name = $request->product_name;
            if($product_name){
                $query->where('product_name','like','%'.$product_name.'%');
            }
            $distributing_company = $request->distributing_company;
            if($distributing_company){
                $query->where('distributing_company','like','%'.$distributing_company.'%');
            }
            $toxic = $request->toxic;
            if($toxic){
                $query->where('toxic', UtilsFacade::formatToBinary($toxic));
            }
            $who_class = $request->who_class;
            if($who_class){
                $query->where('who_class','like','%'.$who_class.'%');
            }
            $composition = $request->composition;
            if($composition){
                $query->where('composition','like','%'.$composition.'%');
            }
            $registrant = $request->registrant;
            if($registrant){
                $query->where('registrant','like','%'.$registrant.'%');
            }
            $type = $request->type;
            if($type){
                $query->where('type','like','%'.$type.'%');
            }
            $phi_days = $request->phi_days;
            if($phi_days){
                $query->where('phi_days',$phi_days);
            }
        }])->where('id',$request->id)->first();
        return $items;
    }

    public function getCropNames(){
        return $this->crops->select('id','name')->orderBy('name', 'asc')->get();
    }


    public function update($id, array $attributes)
    {
        $request = $attributes['request'];
        $item = $this->crops->find($id);

        if($item){
            $item->update($request->only(
                [
                    'name',
                ]
            ));
            $item->agrochem()->sync(Agrochem::findMany($request->agrochems));
            $item->pestsDiseaseWeed()->sync(PestsDiseaseWeed::findMany($request->pests_disease_weed));

            return $item->refresh();
        }else{
            return false;
        }
    }

    public function delete($id)
    {
        $item = $this->crops->find($id);
        if($item){
            $this->imageService->deleteImage($item);
            $item->delete();
            return true;
        }else{
            return false;
        }
    }

    public function filter(array $attributes){
        $request = $attributes["request"];
        $search_value = $request->search_value;
        $order_column = $request->order_column;
        $order_direction = $request->order_direction;
        $per_page = $request->per_page;

        if($order_column==null){
            $order_column="id";
        }
        if($order_direction==null){
            $order_direction="desc";
        }
        if($per_page==null){
            $per_page=config('app.items_per_page');
        }

        $columns_array = array (
            'name'
        );

        $data = Crops::select();



        /**
         * Filter data based on the search query
         */
        if($search_value){
            /**
             * create a nested OR clause to search by specific column
             */
            $data = $data->where(function($query) use($columns_array, $search_value, $request){
                /**
                 * append each table column to the query
                 */
                foreach ($columns_array as $column){
                    $query->orWhere($column,'like','%'.$search_value.'%');
                }
            });
        }else{
            /*
             * Search spefific columns
             */
            $name = $request->name;
            if($name){
                $data = $data->where('name','like','%'.$name.'%');
            }
        }





        /**
         * Set ordering
         */
        $data = $data->orderBy($order_column, $order_direction);


        /**
         * Get the filtered records
         */
        $data = $data->paginate($per_page);
        return $data;
    }

    public function datatable(array $attributes)
    {
        $request = $attributes["request"];


        (int)$draw = $request->draw;
        $start = $request->start;
        $length = $request->length;
        $search_value = $request->search["value"];
        $order_array = $request->order;
        $columns_array = $request->columns;

//        Initial Query  with fields to be selected
        $data = Crops::select(
            'id',
            'name'
        );
        $recordsFiltered = Crops::count();


//        Filter data based on the search query
        if($search_value){
//            create an AND with nested OR clause
            $data = $data->where(function($query) use($columns_array, $search_value){
//                append each table column to the query
                foreach ($columns_array as $column){
                    $query->orWhere($column['data'],'like','%'.$search_value.'%');
                }

            });
            $recordsFiltered = $data->count();
        }


//        Set ordering
        if($order_array){
            foreach ($order_array as $order){
                $column_index = $order['column'];

                $order_column = $columns_array[$column_index]['data'];
                $order_direction = $order["dir"];

                $data = $data->orderBy($order_column, $order_direction);
            }
        }


//        Set limit and offset for pagination
        if($start){
            $data = $data
                ->skip($start);
        }
        if($length){
            $data = $data
                ->take($length);
        }

        $data = $data->get();

        $recordsTotal = Crops::count();



        return response()->json(['draw'=>$draw, 'recordsTotal'=>$recordsTotal, 'recordsFiltered'=>$recordsFiltered, 'data'=>$data]);


    }


}
