<?php


namespace App\Repositories;


use App\Models\Agrochem;
use App\Models\CommercialOrganic;
use App\Models\Crops;
use App\Models\Gap;
use App\Models\HomeMadeOrganic;
use App\Models\LocalNames;
use App\Models\PestsDiseaseWeed;
use App\Services\ImageService;
use Whoops\Exception\ErrorException;

class PestsDiseaseWeedRepositoryMySqlImpl implements  PestsDiseaseWeedRepository
{
    protected  $pestsDiseaseWeed;
    protected  $imageService;
    public function __construct(PestsDiseaseWeed $pestsDiseaseWeed, ImageService $imageService)
    {
        $this->pestsDiseaseWeed = $pestsDiseaseWeed;
        $this->imageService = $imageService;
    }

    public function create($attributes)
    {
        $request = $attributes['request'];
        $saved_item = $this->pestsDiseaseWeed->create($request->only(
            [
                'name',
                'type',
                'scientific_name',
                'crops_affected',
                'description_pest',
                'description_impact',
                'references',
            ]
        ))->refresh();

        $saved_item->localNames()->saveMany(LocalNames::findMany($request->local_names));
        $saved_item->agrochemProducts()->saveMany(Agrochem::findMany($request->agrochem_products));
        $saved_item->gap()->saveMany(Gap::findMany($request->gap));
        $saved_item->homemadeOrganic()->saveMany(HomeMadeOrganic::findMany($request->homemade_organic));
        $saved_item->commercialOrganic()->saveMany(CommercialOrganic::findMany($request->commercial_organic));
        $saved_item->crops()->saveMany(Crops::findMany($request->crops));

        //Save image
        $image = $request->image;
        if($image) {
            $saved_item = $this->uploadImage($image, $saved_item);
        }


        return $saved_item->refresh();
    }

    public function all(){
        return $this->pestsDiseaseWeed->all();
    }

    public function find($id){

        return $this->pestsDiseaseWeed->find($id);
    }

    public function findControlMethods($id){
        $items = PestsDiseaseWeed::with('controlMethods')->where('id',$id)->first();
        return $items;
    }

    public function update($id, array $attributes)
    {
        $request = $attributes['request'];
        $item = $this->pestsDiseaseWeed->find($id);
        if($item){
            $this->pestsDiseaseWeed->find($id)->update($request->only(
                [
                    'name',
                    'type',
                    'scientific_name',
                    'crops_affected',
                    'description_pest',
                    'description_impact',
                    'image',
                    'references',
                ]
            ));

            $item->localNames()->sync(LocalNames::findMany($request->local_names));
            $item->agrochemProducts()->sync(Agrochem::findMany($request->agrochem_products));
            $item->gap()->saveMany(Gap::sync($request->gap));
            $item->homemadeOrganic()->sync(HomeMadeOrganic::findMany($request->homemade_organic));
            $item->commercialOrganic()->sync(CommercialOrganic::findMany($request->commercial_organic));
            $item->crops()->sync(Crops::findMany($request->crops));
            return $item->refresh();
        }else{
            return false;
        }
    }

    public function delete($id)
    {
        $item = $this->pestsDiseaseWeed->find($id);
        if($item){
            $item->delete();
            return true;
        }else{
            return false;
        }
    }

    public function filter(array $attributes){
        $request = $attributes["request"];
        $search_value = $request->search_value;
        $order_column = $request->order_column;
        $order_direction = $request->order_direction;
        $limit = $request->limit;
        $offset = $request->offset;

        if($order_column==null){
            $order_column="id";
        }
        if($order_direction==null){
            $order_direction="desc";
        }
        if($limit==null){
            $limit=10;
        }
        if($offset==null){
            $offset=0;
        }

        $columns_array = array (
            'name',
            'type',
            'scientific_name',
            'description_pest',
            'description_impact',
            'references',
        );

        $data = PestsDiseaseWeed::select();



        /**
         * Filter data based on the search query
         */
        if($search_value){
            /**
             * create a nested OR clause to search by specific column
             */
            $data = $data->where(function($query) use($columns_array, $search_value, $request){
                /**
                 * append each table column to the query
                 */
                foreach ($columns_array as $column){
                    $query->orWhere($column,'like','%'.$search_value.'%');
                }
            });
        }else{
            /*
             * Search spefific columns
             */
            $name = $request->name;
            if($name){
                $data = $data->where('name','like','%'.$name.'%');
            }
            $type = $request->type;
            if($type){
                $data = $data->where('type','like','%'.$type.'%');
            }
            $scientific_name = $request->scientific_name;
            if($scientific_name){
                $data = $data->where('scientific_name','like','%'.$scientific_name.'%');
            }
            $description_pest = $request->description_pest;
            if($description_pest){
                $data = $data->where('description_pest','like','%'.$description_pest.'%');
            }
            $description_impact = $request->description_impact;
            if($description_impact){
                $data = $data->where('description_impact','like','%'.$description_impact.'%');
            }
        }





        /**
         * Set ordering
         */
        $data = $data->orderBy($order_column, $order_direction);

        /**
         * Set limit and offset for pagination
         */
        $data = $data
            ->skip($offset)
            ->take($limit);


        /**
         * Get the filtered records
         */
        $data = $data->get();

        return $data;
    }

    public function datatable(array $attributes)
    {
        $request = $attributes["request"];


        (int)$draw = $request->draw;
        $start = $request->start;
        $length = $request->length;
        $search_value = $request->search["value"];
        $order_array = $request->order;
        $columns_array = $request->columns;

//        Initial Query  with fields to be selected
        $data = PestsDiseaseWeed::select(
            'id',
            'name',
            'type',
            'scientific_name',
            'description_pest',
            'description_impact',
            'references'
        );
        $recordsFiltered = PestsDiseaseWeed::count();


//        Filter data based on the search query
        if($search_value){
//            create an AND with nested OR clause
            $data = $data->where(function($query) use($columns_array, $search_value){
//                append each table column to the query
                foreach ($columns_array as $column){
                    $query->orWhere($column['data'],'like','%'.$search_value.'%');
                }

            });
            $recordsFiltered = $data->count();
        }


//        Set ordering
        if($order_array){
            foreach ($order_array as $order){
                $column_index = $order['column'];

                $order_column = $columns_array[$column_index]['data'];
                $order_direction = $order["dir"];

                $data = $data->orderBy($order_column, $order_direction);
            }
        }


//        Set limit and offset for pagination
        if($start){
            $data = $data
                ->skip($start);
        }
        if($length){
            $data = $data
                ->take($length);
        }

        $data = $data->get();

        $recordsTotal = PestsDiseaseWeed::count();



        return response()->json(['draw'=>$draw, 'recordsTotal'=>$recordsTotal, 'recordsFiltered'=>$recordsFiltered, 'data'=>$data]);


    }

    /**
     * @param $image
     * @param $saved_item
     */
    public function uploadImage($image, $saved_item)
    {
        $extension = $this->imageService->fileExtension($image);
        $fileName = $this->imageService->generateToken() . "." . $extension;

        $uploaded = $this->imageService->save($image, $fileName);
        if ($uploaded['status']) {
            $saved_item->image = $fileName;
            $saved_item->save();
        }

        return $saved_item;
    }


}
