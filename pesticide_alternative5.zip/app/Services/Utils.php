<?php


namespace App\Services;


class Utils
{
    public function formatToBinary($value){
        if($value=="true"|| $value>0 || $value>true){
            $binary_value = 1;
        }else if($value=="false"|| $value<=0 || $value>false){
            $binary_value = 0;
        }

        return $binary_value;
    }

}
