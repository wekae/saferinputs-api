<?php


namespace App\Services;


use App\Http\Requests\PestsDiseaseWeedRequest;
use App\Models\PestsDiseaseWeed;
use App\Repositories\PestsDiseaseWeedRepositoryMySqlImpl;
use Illuminate\Http\Request;

class PestsDiseaseWeedService
{
    protected $pestsDiseaseWeedRepository;

    public function __construct(PestsDiseaseWeedRepositoryMySqlImpl $pestsDiseaseWeedRepository)
    {
        $this->pestsDiseaseWeedRepository = $pestsDiseaseWeedRepository ;
    }

    public function findAll(Request $request){
        $attributes = array("request"=>$request);
        return $this->pestsDiseaseWeedRepository->all($attributes);
    }

    public function find($id){
        return $this->pestsDiseaseWeedRepository->find($id);
    }

    public function findControlMethods($id){
        return $this->pestsDiseaseWeedRepository->findControlMethods($id);
    }

    public function findAgrochems(Request $request){
        $attributes = array("request"=>$request);
        return $this->pestsDiseaseWeedRepository->findAgrochems($attributes);
    }

    public function getPestDiseasesWeedsNames(){
        return $this->pestsDiseaseWeedRepository->getPestDiseasesWeedsNames();
    }

    public function create(PestsDiseaseWeedRequest $request){
        $attributes = array("request"=>$request);
        return $this->pestsDiseaseWeedRepository->create($attributes);
    }

    public function update(PestsDiseaseWeedRequest $request, $id){
        $attributes = array("request"=>$request);
        return $this->pestsDiseaseWeedRepository->update($id, $attributes);
    }

    public function delete($id){
        return $this->pestsDiseaseWeedRepository->delete($id);
    }

    public function filter(Request $request){
        $attributes = array('request'=>$request);
        return $this->pestsDiseaseWeedRepository->filter($attributes);
    }

    public function summaryNames(Request $request){
        $attributes = array('request'=>$request);
        return $this->pestsDiseaseWeedRepository->summaryNames($attributes);
    }

    public function dataTable(Request $request){
        $attributes = array("request"=>$request);
        return $this->pestsDiseaseWeedRepository->datatable($attributes);
    }
}
