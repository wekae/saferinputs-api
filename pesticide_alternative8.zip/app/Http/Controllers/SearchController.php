<?php

namespace App\Http\Controllers;

use App\Models\ActiveIngredients;
use App\Models\Agrochem;
use App\Models\CommercialOrganic;
use App\models\ControlMethods;
use App\Models\Crops;
use App\Models\Gap;
use App\Models\HomeMadeOrganic;
use App\Models\LocalNames;
use App\Models\PestsDiseaseWeed;
use App\Services\PDWLengthAwarePaginator;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Spatie\Searchable\Search;

class SearchController extends Controller
{
    protected $successStatus = 200;
    protected $createdStatus = 201;
    protected $noContentStatus = 204;
    protected $badRequestStatus = 400;
    protected $unauthorizedStatus = 401;
    protected $notFoundStatus = 404;
    protected $unprocessableStatus = 404;
    protected $notImplementedStatus = 501;



    public function __construct()
    {}

    private function failureMessage($code, $message)
    {

        return [
            'code' => $code,
            'message' => $message,
            'success' => false,
        ];

    }

    private function successMessage($code, $message, $payload)
    {

        return [
            'code' => $code,
            'message' => $message,
            'success' => true,
            'data' => $payload,
        ];

    }


    public function search(Request $request){
        return PestsDiseaseWeed::search($request->value)->get();
    }
    public function searchAlt(Request $request){
        if($request->value == null){
            $value = "";
        }else{
            $value = $request->value;
        }
        $searchResults = (new Search())
            ->registerModel(PestsDiseaseWeed::class,
                [
                    'name',
                    'type',
                    'scientific_name',
                    'description_pest',
                    'description_impact',
                    'references',
                ])
            ->registerModel(Crops::class,
                [
                    'name',
                ])
            ->registerModel(Agrochem::class,
                [
                    'product_name',
                    'distributing_company',
                    'toxic',
                    'who_class',
                    'composition',
                    'registrant',
                    'type',
                    'phi_days',
                ])
            ->registerModel(CommercialOrganic::class,
                [
                    'name',
                    'manufacturer',
                    'distributor',
                    'category',
                    'contact_details',
                    'external_links',
                    'application_details',
                ])
            ->registerModel(Gap::class,
                [
                    'name',
                    'practices',
                    'references'
                ])
            ->registerModel(HomeMadeOrganic::class,
                [
                    'name',
                    'practices',
                    'external_links',
                    'references',
                ])
            ->registerModel(ControlMethods::class,
                [
                    'name',
                    'options',
                    'category',
                    'external_links',
                ])
            ->registerModel(ActiveIngredients::class,
                [
                    'name',
                    'potential_harm',
                    'fish',
                    'daphnia',
                    'bee',
                    'algae',
                    'dt50',
                    'koc',
                    'gus',
                    'carcinogenicity',
                    'mutagenicity',
                    'edc',
                    'reproduction',
                    'ache',
                    'neurotoxicant',
                    'who_classification',
                    'tp_sum',
                ])
            ->search($value);



        if(sizeof($searchResults)>0){
            $status_code = $this->successStatus;
            $per_page =   $request->per_page? $request->per_page: 20;
            $page =   $request->page? $request->page: 1;

            $pagedSearchResults = $this->paginate($searchResults, $value, $per_page, $page);

            $message = sizeof($searchResults)." Items found";
            $response = $this->successMessage($status_code, $message, $pagedSearchResults);
            return response($response, $status_code);
        }else{
            $status_code = $this->notFoundStatus;
            $message = "Items not found";
            $response = $this->failureMessage($status_code, $message);
            return response($response, $status_code);
        }


    }

    public function paginate($data, $searchValue,  $perPage = 15, $page = 1, $routeName = '/api/search_alt/')
    {
        $results = collect($data)->slice(($page - 1) * $perPage, $perPage);

        $paginator = new PDWLengthAwarePaginator($results, count($data), $perPage, $page);


        $paginator->setPath($routeName.$searchValue);

        return $paginator->toArray();
    }

}
